package com.example.SpringBootWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
