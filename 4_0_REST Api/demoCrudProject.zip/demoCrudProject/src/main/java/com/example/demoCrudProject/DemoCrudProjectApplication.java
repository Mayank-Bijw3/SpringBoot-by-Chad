package com.example.demoCrudProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCrudProjectApplication.class, args);
	}

}
